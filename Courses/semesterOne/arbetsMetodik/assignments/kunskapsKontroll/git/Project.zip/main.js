function main() {
    let text = "This is a javascript";

}