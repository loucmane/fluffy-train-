window.onload = function () {

    alert('ello');
}