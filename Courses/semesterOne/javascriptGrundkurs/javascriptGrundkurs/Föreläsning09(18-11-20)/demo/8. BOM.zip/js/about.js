function goBack() {
    window.history.back();
}

function closeCurrent() {
    window.close();
}