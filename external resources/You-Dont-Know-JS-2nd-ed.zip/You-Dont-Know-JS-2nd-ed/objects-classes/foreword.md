# You Don't Know JS Yet: Objects & Classes - 2nd Edition
# Foreword

| NOTE: |
| :--- |
| Work in progress |
